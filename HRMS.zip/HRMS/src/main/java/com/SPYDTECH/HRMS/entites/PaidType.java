package com.SPYDTECH.HRMS.entites;

public enum PaidType {
    MASTERCARD,
    PAYPAL,
    VISA;
}