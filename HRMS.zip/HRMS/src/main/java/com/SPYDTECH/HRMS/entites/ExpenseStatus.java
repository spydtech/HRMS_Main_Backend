package com.SPYDTECH.HRMS.entites;

public enum ExpenseStatus {
    APPROVED,
    PENDING;
}